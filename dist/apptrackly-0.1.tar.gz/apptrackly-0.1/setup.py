from distutils.core import setup

setup(
    name='apptrackly',
    packages=['apptrackly'],
    version='0.1',
    description='Python lib for apptrackly',
    author='Doniyor Jurabayev',
    author_email='behconsci@gmail.com',
    url='https://github.com/behconsci/apptracklypython',
    download_url='https://github.com/behconsci/apptracklypython/archive/0.1.tar.gz',
    keywords=['track', 'monitor', 'bug'],
    classifiers=[],
)
